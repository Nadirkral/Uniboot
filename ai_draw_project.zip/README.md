# AI Draw App

Bu layihə, istifadəçinin verdiyi üz şəklini avtomatik tanıyaraq onu addım-addım rəsmlə çəkən, video yaradan və nəticəni PDF və ASCII sənətə çevirən tam avtomatlaşdırılmış AI sistemidir.

## Xüsusiyyətlər

- Üz tanıma (Haar Cascade)
- AI ilə stilizə edilmiş çəkiliş
- Addım-addım rəsmləmə animasiyası (video çıxış)
- Stil transferi (OpenCV ilə)
- PDF hesabat çıxışı
- ASCII sənətə çevirmə
- Tam CLI dəstəyi

## Qovluq quruluşu

```
ai_draw_project/
├── images/              # İstifadəçi şəkilləri
├── outputs/             # Nəticələr: video, şəkillər, PDF
├── styles/              # Stil şəkilləri (istəyə bağlı)
├── main.py              # Əsas Python kodu
├── README.md            # Layihə təsviri
└── requirements.txt     # Lazımi paketlər
```

## İşlətmək üçün

```bash
python3 main.py
```

## Müəllif

Nadir — 2025  
